$("#fromScreensaver").click(function() {
    window.location.href = "home";
});