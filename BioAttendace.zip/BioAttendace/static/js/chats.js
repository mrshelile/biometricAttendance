$(document).ready(function(){

    google.charts.load('current', {'packages':['corechart']});
    google.charts.setOnLoadCallback(drawChart);
    
    function drawChart() {
    
    var data = google.visualization.arrayToDataTable([
    ['Lessons', 'Weecky'],
    ['Monday', 4],
    ['Tuesday', 4],
    ['Wedsday', 5],
    ['Thursday', 3],
    ['friday', 4]
    ]);
    
    var options = {
    title: 'Weeckly Attendance statistics '
    };
    
    var chart = new google.visualization.PieChart(document.getElementById('weeckly'));
    
    chart.draw(data, options);
    }
    
    
    });

    $(document).ready(function(){

        google.charts.load('current', {'packages':['corechart']});
        google.charts.setOnLoadCallback(drawChart);
        
        function drawChart() {
        
        var data = google.visualization.arrayToDataTable([
        ['Lessons', 'Weecky'],
        ['First Month', 4],
        ['Second Month', 4],
        ['Third Month', 5],
        ['Fourth Month', 3],
        ['Firth Month', 4],
        ['Sixth Month', 4],
        ]);
        
        var options = {
        title: 'Monthly Attendance '
        };
        
        var chart = new google.visualization.PieChart(document.getElementById('monthly'));
        
        chart.draw(data, options);
        }
        
        
        });