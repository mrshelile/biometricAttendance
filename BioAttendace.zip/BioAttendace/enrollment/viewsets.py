from django.http import request
from django.http.response import JsonResponse
from enrollment.views import timetable
from rest_framework import status, viewsets
from enrollment.models import Device, TimeTableItem
from .serializers import TimetableItemSerializer
from rest_framework.views import APIView
from rest_framework.response import Response

def TimetableItemViewset(request):

    if request.method == 'GET':
        day =request.GET.get('day', None)
        if day is not None:
            snippets = TimeTableItem.objects.filter(day=day.lower())
            serializer = TimetableItemSerializer(snippets, many=True)

            return JsonResponse(serializer.data, safe=False)
        else:
            return JsonResponse("", safe=False)

    else:
        return JsonResponse("Not", safe=False)
                
def changeDeviceStateViewset(request):
    if request.method == 'GET':
        device =request.GET.get("device",None)
        status =request.GET.get("status",None)
        if(status):
            devices = Device.objects.filter(device_id=device).update(status="attendace")
            
        else:
            devices = Device.objects.filter(device_id=device).update(status="register")
              
        return JsonResponse("", safe=False)
    return JsonResponse("NOT", safe=False)