from django.contrib.auth.tokens import PasswordResetTokenGenerator
import six
from django.core.mail import send_mail
from .models import Student,Course
from django.contrib.sites.shortcuts import get_current_site
from django.urls import reverse
from six import text_type 
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode
from datetime import datetime
from .models import AttendanceBook,TimeTableItem,Student

class AccountActivationTokenGenerator(PasswordResetTokenGenerator):
    def _make_hash_value(self, user, timestamp):
        return (
            six.text_type(user.identifier) + six.text_type(timestamp) +
            six.text_type(user.username)
        )

account_activation_token = AccountActivationTokenGenerator()



def toChangePasswordEmail(user,request,password):
    uidb64 = urlsafe_base64_encode(force_bytes(user.identifier))
    domain = get_current_site(request).domain
    encoded_email =urlsafe_base64_encode(force_bytes(user.username))
    link = reverse('enrollment:toChangePassword',kwargs={'uidb64':uidb64,"token":account_activation_token.make_token(user),'username':encoded_email,"password":urlsafe_base64_encode(force_bytes(password))})
    final_link = 'http://'+domain+link
    send_mail(
    'Register Password',
    'You have Being added to biometric Based Attendance System, username or email as '
    +user.email+' use  '+ password +'   as old password '
    "to registered your password here "+ final_link,
    'noreplay@biometricRegistration.co.ls',
    [user.email], fail_silently=False)
    

def cancelClassNotification(timetable,isActive):
    students = Student.objects.all()
    emails = list()
    courses = Course.objects.all()
    for student in students:
        for course in courses:
            if(course == student.course):
                if(timetable[0].subject.course == course):
                   emails.append(student.email)
                   
    if isActive:
        send_mail(
        'Re-activated Lecture Class',
        'Your notified that '+str(timetable[0].subject)+ " will continue on "+str(timetable[0].start_time)+" "+str(timetable[0].day),
        'noreplay@biometric.com',
        emails,)
    else:
        send_mail(
        'Cancelled Lecture Class',
        'Your notified that '+str(timetable[0].subject)+ " is cancelled for "+str(timetable[0].start_time)+" "+str(timetable[0].day)+" lecture class",
        'noreplay@biometricRegistration.co.ls',
        emails, fail_silently=False,)
        
def deleteClassNotification(deletedClass):
    students = Student.objects.all()
    emails = list()
    courses = Course.objects.all()
    for student in students:
        for course in courses:
            if(course == student.course):
                if(deletedClass[0].subject.course == course):
                   emails.append(student.email)        
    
    send_mail(
        'Removed Lecture Class',
        'Your notified that '+str(deletedClass[0].subject)+ " is removed from timetable for "+str(deletedClass[0].start_time)+" "+str(deletedClass[0].day),
        'noreplay@biometricRegistration.co.ls',
        emails, fail_silently=False,)

def findDay(day,month,year):
    # day, month, year = (int(i) for i in date.split(' '))   
    born = datetime.date(year, month, day)
    return born.strftime("%A")
 
# Driver program
print(datetime.now().strftime("%A"))

def registerAttendance(device,devices):
    dayWeek = datetime.now().strftime("%A")
    if dayWeek.lower() == "sunday":
        dayWeek = "Monday"
          
    timeNow  = datetime.now().time()
    items = TimeTableItem.objects.filter(room__icontains=device.devices_location,day__icontains=dayWeek,
                                         start_time__lte=timeNow,end_time__gte =timeNow)
    print(items)
    data = device.temp['Templates']
    template = hex(data) 
    template = bytes(template,'utf-8')  
    print(template)
    # student =Student.objects.filter(fingerprint_template__icontains=template)
    students =Student.objects.all()
    student =None
    for val in students:
        if val:
            if val.fingerprint_template.__contains__(template):
                if val.course == items[0].subject.course:
                    student =val
    if items and student:
        book = AttendanceBook.objects.create(subject=items[0].subject,student=student)
        book.save()
        print(book)
    devices.update(temp=None)    

def takeAttendance(devices):
    
    for device in devices:
        if device:
            if device.status == "attendace":
                registerAttendance(device,devices)
             
               