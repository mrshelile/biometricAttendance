from django.contrib import admin
from django.urls import path
from . import views
from .viewsets import TimetableItemViewset,changeDeviceStateViewset
from rest_framework import routers
from django.contrib.auth import views as v
from django.contrib.auth import views as auth_views

# router = routers.DefaultRouter(trailing_slash=False)
app_name ="enrollment"
# router.register('getTimetableItems', TimetableItemViewset)
urlpatterns = [
    path('',views.screensaver,name='screensaver'),
    path('home',views.index,name='index'),
    path('studentManagement',views.studentManagement,name='studentManagement'),
    path('attendaceBook',views.attendaceBook,name='attendaceBook'),
    path('biometricEnrollment',views.biometricEnrollment,name='biometricEnrollment'),
    path('timetables',views.timetable,name='timetables'),
    path('addTimetableItem',views.addTimetableItem,name='addTimetableItem'),
    path('login/',views.signin,name='login'),
    path('registration',views.registration,name='registration'),
    path('logout', views.user_logout, name='logout'),
    # path('getTimetable',views.getTimetable,name='getTimetable'),
    path('getTimetable',TimetableItemViewset,name='getTimetable'),
    path('changeDeviceState',changeDeviceStateViewset,name='changeDeviceState'),
    path('pairDevice',views.pairDevice,name='pairDevice'),
    path('addDevice',views.addDevice,name='addDevice'),
    path('removeDevice',views.removeDevice,name='removeDevice'),
    path('takePrint',views.takePrint,name='takePrint'),
    path('enrollUserToBiometric',views.enrollUserToBiometric,name='enrollUserToBiometric'),
    path('deleteClass/', views.deleteClass, name='deleteClass'),
    path('cancelClass/', views.cancelClass, name='cancelClass'),
    # path(r'^password_change/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>[0-9A-Za-z]{1,13}-[0-9A-Za-z]{1,20})/$',
    #             views.password_change, name='password_change'),
      path(
        'change-password/',
        auth_views.PasswordChangeView.as_view(
            template_name='registration/change-password.html',
            success_url = '/'
        ),
        name='change_password'
    ),
    path('changeDeviceStateApi',views.changeDeviceStateApi,name='changeDeviceStateApi'),  
    path('checkDeviceState', views.checkDeviceState, name='checkDeviceState'),
    path('toChangePassword/<uidb64>/<token>/<str:username>/<str:password>/', views.toChangePassword, name='toChangePassword'),  
]
# urlpatterns += router.urls
