from django.db import models
from uuid import uuid4
from django.contrib.auth.models import AbstractUser
from django.db.models.base import Model
from django.urls import reverse
import jsonfield

class School(models.Model):
   identifier = models.UUIDField(primary_key=True,default=uuid4,editable=False)
   created = models.DateTimeField(auto_now_add=True,null=True)
   name = models.CharField(max_length=300,verbose_name="School Name")
   code = models.CharField(max_length=50,verbose_name="School Code")
   
   class Meta:
       ordering= ("-created",)
   def __str__(self):
       return self.name

class Course(models.Model):
    identifier = models.UUIDField(primary_key=True,default=uuid4,editable=False)
    created = models.DateTimeField(auto_now_add=True,null=True)
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    name = models.CharField(max_length=300,null=True)
    code = models.CharField(max_length=20)
    
    class Meta:
           ordering= ("-created",)
    def __str__(self):
       return self.name

class CustomUser(AbstractUser):
    username = models.CharField(max_length=500,unique=True,default='')
    created = models.DateTimeField(auto_now_add=True,null=True)
    identifier = models.UUIDField(primary_key=True,default=uuid4,editable=False)
    fingerprint_template = models.BinaryField(verbose_name="Fingerprint template",null=True,editable=True)
    phone_numbers=models.IntegerField(verbose_name="Phone numbers",null=True,blank = True)

    class Meta:
        ordering= ("-created",)
    
    def save(self, *args, **kwargs):
        if(self.username == "none"):
          self.username = uuid4().hex[:30]
        super().save(*args, **kwargs)
        
    def __str__(self):
        
        if self.first_name or  self.last_name: 
            return  self.first_name +" "+ self.last_name
        else:
            return self.username
    
class Student(CustomUser):
    course = models.ForeignKey(Course,on_delete=models.CASCADE)
    student_number = models.CharField(max_length=400,verbose_name="Student Number")

    class Meta:
        verbose_name ="Student"
    def __str__(self):
        return self.first_name


class Lecture(CustomUser):
    # department = models.ForeignKey(School,on_delete=models.CASCADE)
    is_HOD = models.BooleanField(default=False,verbose_name="HOD")
    #course = models.ManyToManyField(Course)
    # subject = models.ForeignKey(Subject,on_delete=models.CASCADE,null=True,blank=True)
    class Meta:
        verbose_name ="Lecture"
    def __str__(self):
        return self.first_name


class Subject(models.Model):
    identifier = models.UUIDField(primary_key=True,default=uuid4,editable=False)    
    created = models.DateTimeField(auto_now_add=True,null=True,verbose_name="Time added")
    name = models.CharField(max_length=50)
    code = models.CharField(max_length=20)
    course = models.ForeignKey(Course,on_delete=models.CASCADE)
    teacher = models.ForeignKey(Lecture,on_delete=models.CASCADE,null=True,blank=True)
    # course = models.ForeignKey(Course,on_delete=models.CASCADE)
    def __str__(self):
       return self.name

class Device(models.Model):
    STATUS =   (('register','Add new User'),
                ('attendace','Take Attendance'))
    identifier = models.UUIDField(primary_key=True,default=uuid4,editable=False)
    devices_location = models.CharField(max_length=300,verbose_name="Location")
    device_id = models.CharField(max_length=500,verbose_name="Device Mac Address")
    last_response = models.DateTimeField(auto_now_add=False,null=True,blank=True ,verbose_name="Last Response")
    current_class = models.CharField(default='No Class',max_length=100,null=True,blank=True)
    created = models.DateTimeField(auto_now_add=True,null=True,blank=True,verbose_name="Time added")
    is_in_progress = models.BooleanField(default=False,verbose_name="Is still during lesson?",null=True,blank=True)
    status= models.CharField(max_length=60,choices=STATUS,null=True,blank=True,default="attendace")
    diagnose_message = models.CharField(max_length=1000,null=True,blank=True,verbose_name="Diagnose Message")
    temp = jsonfield.JSONField(null=True,blank=True)
    class Meta:
       ordering= ("-created",)

    def __str__(self):
        return self.device_id

# class Lesson(models.Model):
#     identifier = models.UUIDField(primary_key=True,default=uuid4,editable=False)
#     name = models.CharField(max_length=500,verbose_name="Lesson name")
#     lecture = models.ForeignKey(Lecture,on_delete=models.CASCADE)
#     start =models.DateTimeField(verbose_name="Start time")
#     end = models.DateTimeField(verbose_name="End time")

class TimeTableItem(models.Model):
    DAYS_OF_THE_WEEK = (
        ('Monday', 'Monday'),
        ('Tuesday', 'Tuesday'),
        ('Wednesday', 'Wednesday'),
        ('Thursday', 'Thursday'),
        ('Friday', 'Friday'),
        ('Satuday', 'Satuday')
    )
    # course = models.ForeignKey(Course, on_delete=models.CASCADE)
    identifier = models.UUIDField(primary_key=True,default=uuid4,editable=False)
    subject = models.ForeignKey(Subject,verbose_name="Subject",on_delete=models.CASCADE)
    # lecture = models.ForeignKey(Lecture, on_delete=models.CASCADE)
    day = models.CharField(max_length=20, choices=DAYS_OF_THE_WEEK,null=False)
    is_active = models.BooleanField(default=True,verbose_name="Active")
    start_time = models.TimeField()
    end_time = models.TimeField()
    room = models.CharField(max_length=20)
    def __str__(self):
        return 'Subject :{},Room :{} ,lecture:{}, time:{}-{}'.format(self.subject,self.room,
         self.subject.teacher, self.start_time, self.end_time)

    def save(self, *args, **kwargs):
        self.day = self.day.lower()
        return super(TimeTableItem, self).save(*args, **kwargs)

    class Meta:
        ordering = ('start_time',)

# class TimeTable(models.Model):
#     identifier = models.UUIDField(primary_key=True,default=uuid4,editable=False)
#     course = models.ForeignKey(Course,on_delete=models.CASCADE)
#     # course = models.ForeignKey(Lesson, on_delete=models.CASCADE)
#     time_table_item = models.ForeignKey(TimeTableItem, on_delete=models.CASCADE)
#     close = models.DateTimeField(verbose_name='End of Lecture Classes')
    
#     def __str__(self):
#         return 'Lesson:{}, Day:{}, End of Lecture Classes:{}'.format(self.time_table_item,
#          self.day, self.close)
        
#     class Meta:
#         verbose_name = 'TimeTable'
#         verbose_name_plural = 'TimeTables'

class AttendanceBook(models.Model):
    identifier = models.UUIDField(primary_key=True,default=uuid4,editable=False)
    created = models.DateTimeField(auto_now_add=True,null=True)
    student = models.ForeignKey(to=Student,verbose_name="Fingerprint template",on_delete=models.CASCADE)
    subject = models.ForeignKey(Subject,on_delete=models.CASCADE)
    
    class Meta:
        ordering= ("-created",)

    def __str__(self):
        return 'template: {}, subject: {}, date: {}'.format(self.student.fingerprint_template,self.subject,self.created)

class DeviceToBePaired(models.Model):
    # identifier = models.UUIDField(primary_key=True,default=uuid4,editable=False)
    created = models.DateTimeField(auto_now_add=True,null=True)
    ip_address = models.CharField(max_length=100,null=True,blank=True)
    mac_address = models.CharField(max_length=100,null=True,blank=True)
    def __str__(self):
        return 'ip Address: {}, mac Address: {}'.format(self.ip_address,self.mac_address)          
# Create your models here.