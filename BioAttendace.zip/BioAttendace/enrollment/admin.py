from enrollment.models import CustomUser, Subject, School, Device, Lecture,  Student,  TimeTableItem,Course, AttendanceBook,DeviceToBePaired
from django.contrib import admin

admin.site.register(School)
admin.site.register(CustomUser)
admin.site.register(Lecture)
admin.site.register(Student)
admin.site.register(Subject)
admin.site.register(Device)
admin.site.register(Course)
admin.site.register(DeviceToBePaired)
# admin.site.register(TimeTable)
admin.site.register(TimeTableItem)
admin.site.register(AttendanceBook)





# Register your models here.
