from rest_framework import serializers
from enrollment.models import Lecture, Subject, TimeTableItem 

class LectureSerializer(serializers.ModelSerializer):
    class Meta:
        model = Lecture
        fields = "__all__"

class SubjectSerializer(serializers.ModelSerializer):
    class Meta:
        model = Subject
        fields = "__all__"

class TimetableItemSerializer(serializers.ModelSerializer):
    subject = SubjectSerializer()
    
    class Meta:
        model = TimeTableItem
        fields = "__all__"
