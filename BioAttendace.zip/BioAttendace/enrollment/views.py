from django.shortcuts import render,redirect,HttpResponse
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import AttendanceBook, Device, Subject, Course,Lecture,TimeTableItem,Student,DeviceToBePaired
from django.http import JsonResponse
from django.core import serializers
import json
import dateparser
from django.views.decorators.csrf import csrf_exempt
from django.utils import timezone
from django.contrib.auth.hashers import make_password
from django.contrib import messages
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.forms import PasswordChangeForm
from django.utils.encoding import force_text,force_str
from django.utils.http import urlsafe_base64_decode
from .util import cancelClassNotification ,deleteClassNotification,toChangePasswordEmail,takeAttendance
from .generate_password import generate_random_password
# class ActivateAccountView(View):
#     def get(self, request, uidb64, token):
#         try:
#             uid = force_text(urlsafe_base64_decode(uidb64))
#             user = User.objects.get(pk=uid)
#         except (TypeError, ValueError, OverflowError, User.DoesNotExist):
#             user = None

#         if user is not None and account_activation_token.check_token(user, token):
#             user.profile.email_confirmed = True
#             user.save()
#             login(request, user)
#             return redirect('profile')
#         else:
#             # invalid link
#             return render(request, 'registration/invalid.html')

# def password_change(request):
#     if request.method == 'POST':
#         form = PasswordChangeForm(request.user, request.POST)
#         if form.is_valid():
#             user = form.save()
#             update_session_auth_hash(request, user)  # Important!
#             messages.success(request, 'Your password was successfully updated!')
#             return redirect('change_password')
#         else:
#             messages.error(request, 'Please correct the error below.')
#     else:
#         form = PasswordChangeForm(request.user)
#     return render(request, 'registration/password_change.html', {
#         'form': form
#     })

@login_required(login_url = 'enrollment:login')
def index(request):
    paired_devices = Device.objects.all()
    paired_number = Device.objects.count()
    newDevices = DeviceToBePaired.objects.all()
    allNewDevices =DeviceToBePaired.objects.count()
    context={
       "paired_devices":paired_devices,
        "newDevices":newDevices, 
        "paired_number":paired_number,
        "allNewDevices":allNewDevices,
    }
    return render(request,'index/index.html',context)

def toChangePassword(request,uidb64,token,username,password):
    Lecture.objects.filter(username= force_str(urlsafe_base64_decode(username))).update(is_active=True)
    user = authenticate(request, username= force_str(urlsafe_base64_decode(username)), password=force_str(urlsafe_base64_decode(password)))
    if user is not None:
        login(request, user)
        return redirect('enrollment:change_password')
    else:
        messages.error(request,"Unexpected error occured")
        return redirect('enrollment:change_password')

@login_required(login_url = 'enrollment:login')
def screensaver(request):

    return render(request,'screensaver/screensaver1.html')

def registration(request):
    
    # if request.method == 'POST':


    return render(request,'registration/registration.html')



@login_required(login_url = 'enrollment:login')
def studentManagement(request):
    mod= Subject.objects.all()
    context ={
        "subject":mod
    }
    return render(request,'studentManagement/studentManagement.html',context)


@login_required(login_url = 'enrollment:login')
def biometricEnrollment(request):
    mod= Course.objects.all()
    device = Device.objects.all()
    subjects = Subject.objects.all()
    context ={
        "courses":mod,
        "devices":device,
        "subjects":subjects
    }
    return render(request,'biometricEnrollment/biometricEnrollment.html',context)

@login_required(login_url = 'enrollment:login')
def enrollUserToBiometric(request):
    if request.method == 'POST':
        device_id = request.POST.get('device')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        course = request.POST.get('course')
        user = request.POST.get('user')
        email = request.POST.get('email')
        isHop = request.POST.get('isHop')
        subjects = request.POST.getlist('subjects[]')
        course = Course.objects.filter(code=course)
        std_number =request.POST.get('student_number')
        password = generate_random_password()
        devices = Device.objects.filter(device_id__contains=device_id).update(status="register")
        devices = Device.objects.filter(device_id__contains=device_id)
        
        for device in devices:
            data = device.temp
        
        if user == "Lecture":
                lecture = Lecture.objects.create(username=email,password=make_password(password),email=email,first_name=first_name,last_name=last_name,fingerprint_template=None,is_active=False)
                toChangePasswordEmail(lecture,request,password) 
                lecture.save()
                subjectsAssign = Subject.objects.filter(identifier__in=subjects).update(teacher=lecture)
                messages.error(request,"Lecture registered Successfully")
        
        elif data :
            # template +=temp
            # templates = data['Templates']
            # template =0
            # for temp in templates:
            #     template = hex(template) 
            # template = bytes(templates,'utf-8')   
            templates = data['Templates']
            template = hex(templates) 
            template = bytes(template,'utf-8')  
            if std_number:
                print(template)  
                student = Student.objects.create(username=email,password=make_password(password),email=email,first_name=first_name,last_name=last_name,fingerprint_template=template,student_number= std_number,course=course[0])
                student.save()
                devices.update(temp=None,status="attendace")
                messages.error(request,"Student registered Successfully")
            else:
                messages.error(request,"No entered Student number")     
        else:
            messages.error(request,"No fingerprint has been received")
                   
    return redirect(to='enrollment:biometricEnrollment')

@login_required(login_url = 'enrollment:login')
def timetable(request):
    mod= Subject.objects.exclude(teacher__isnull=True)
    lectures= Lecture.objects.all()
    context ={
        "subjects":mod,
        "lectures":lectures,
    }
    return render(request,'timetable/timetables.html',context)  
  
@login_required(login_url = 'enrollment:login')
def addTimetableItem(request):

    if request.method == 'POST':
        subject = request.POST.get('subject')
        room = request.POST.get('room')
        day = request.POST.get('day')
        start_time = request.POST.get('starttime')
        end_time = request.POST.get('endtime')
        subjectObj = Subject.objects.get(code=subject)
        clash = False
        items = TimeTableItem.objects.all()
        for obj in items:
            # print(obj.room.lower()+"obj "+room.lower()+"room")
            if(room.lower() == obj.room.lower() and obj.day.lower()==day.lower()):
                if(dateparser.parse(start_time) < dateparser.parse(str(obj.end_time))):
                   clash = True
        if(not clash):          
            timetable = TimeTableItem.objects.create(subject=subjectObj,day=day,start_time=start_time,end_time=end_time,room=room)
            timetable.save()
        else:
            messages.error(request,"This period is already occupied by another Subject")   
    return redirect('enrollment:timetables')    

@login_required(login_url = 'enrollment:login')
def deleteClass(request):
    id =request.GET.get('id', None)
    if not id:
        id=""
    temp =TimeTableItem.objects.filter(identifier__icontains=id) 
    deleteClassNotification(temp)
    timetable = TimeTableItem.objects.filter(identifier__icontains=id).delete()
  
    
    data ={
        "status":"ok",
    } 
    # # for obj in timetable:
    # #     data.append(obj)
    # timetable_serializer= serializers.serialize("json",timetable[0])
    return JsonResponse(data=data,safe=False)

@login_required(login_url = 'enrollment:login')
def cancelClass(request):
    id =request.GET.get('id', None)
    if not id:
        id=""
       
    timetable = TimeTableItem.objects.filter(identifier__icontains=id)
    stop=''    
    for value in timetable:
        stop = value
    change =not stop.is_active 
   
    result = TimeTableItem.objects.filter(identifier__icontains=id).update(is_active=change)
    
    cancelClassNotification(timetable,change)
    data ={
        "status":"ok",
        "active":change,
    } 
    # # for obj in timetable:
    # #     data.append(obj)
    # timetable_serializer= serializers.serialize("json",timetable[0])
    return JsonResponse(data=data,safe=False)

def getStudentAttendance(request):
    
    return JsonResponse()

@login_required(login_url = 'enrollment:login')
def getTimetable(request):
    day =request.GET.get('day', None)
    timetable = TimeTableItem.objects.filter(day__icontains=day.lower())
    # data = [] 
    # for obj in timetable:
    #     data.append(obj)
    timetable_serializer= serializers.serialize("json",timetable)
    data ={
        "data":timetable_serializer
    }
    return JsonResponse(data=data,safe=False)


@login_required(login_url = 'enrollment:login')
def attendaceBook(request):
    attended  = AttendanceBook.objects.all()
    subject = Subject.objects.all()                         
    context= {
        "attends":attended,
        "subjects":subject
    }
    
    return render(request,'attendaceBook/attendaceBook.html',context)
    
def signin(request):
    
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('enrollment:screensaver')
        else:
            messages.error(request,"username or password is incorrent")
            return redirect('enrollment:login')
           
    return render(request,'user_auth/login1.html')    

@login_required(login_url = 'enrollment:login')
def user_logout(request):
    logout(request)
    return redirect(to='enrollment:login')

@csrf_exempt
def pairDevice(request):
    data = json.loads(request.body)
    devices = Device.objects.filter(device_id__contains=data['Mac Address'])
    waiting = DeviceToBePaired.objects.filter(mac_address__contains=data['Mac Address'])
    
    print(waiting) 
    if not waiting and not devices:
        toBe = DeviceToBePaired.objects.create(ip_address=data['IP Address'],mac_address=data['Mac Address'])
        toBe.save()        
    print(json.loads(request.body))
    
    return HttpResponse(status=200)

@login_required(login_url = 'enrollment:login')
def addDevice(request):
    if request.method == "POST":
        location = request.POST.get('device_location')
        device_id = request.POST.get('mac_address')
        if location and device_id:
            device = Device.objects.create(last_response=timezone.now(),devices_location=location,device_id=device_id)
            toBe = DeviceToBePaired.objects.filter(mac_address__contains=device_id).delete()    
            device.save()
    return redirect(to='enrollment:index')

@login_required(login_url = 'enrollment:login')
def removeDevice(request):
    if request.method == "POST":
        device_id = request.POST.get('device_id')
        if device_id:
            Device.objects.filter(device_id__contains=device_id).delete()
    return redirect(to='enrollment:index')

@csrf_exempt
def takePrint(request):
    
    if request.method == "POST":
        data = json.loads(request.body)
        devices = Device.objects.filter(device_id__contains=data['Mac Address'])
        print(data)
        if devices:
            devices.update(temp=data)
            takeAttendance(devices)
            
            
    return HttpResponse(status=200)

@csrf_exempt
def checkDeviceState(request):
    
    if request.method == "POST":
        data = json.loads(request.body)
        devices = Device.objects.filter(device_id__contains=data['Mac Address'])
        status =''
        print(devices)
        if devices:
            for device in devices:
                status = device.status
        
        data = {
            "state":status.lower()
        }
            
    return JsonResponse(data=data,safe=False)

@login_required(login_url = 'enrollment:login')
def changeDeviceStateApi(request):
    device =request.GET.get('device', None)
    
    if device:
        
        if str(device).__contains__("choose"):
            print(device) 
            devices = Device.objects.all().update(status='attendace')
        else:
            print(device)    
            devices = Device.objects.filter(device_id__contains=device).update(status='register') 
         
    
    return HttpResponse(status=200)